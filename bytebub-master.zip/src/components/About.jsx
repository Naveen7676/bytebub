import { History, Users, Lightbulb, Code2 } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-16 sm:py-20 lg:py-28 relative overflow-hidden mx-4 sm:mx-6 lg:mx-8 mt-12">
      {/* Background elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute w-full h-full bg-gradient-to-br from-purple-600/5 to-blue-600/5 rounded-2xl opacity-80"></div>
        <div className="absolute top-0 left-0 w-64 h-64 bg-gradient-to-br from-purple-600/10 to-transparent rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-gradient-to-tl from-blue-600/10 to-transparent rounded-full blur-3xl translate-x-1/2 translate-y-1/2"></div>
        <div className="absolute top-1/2 left-1/2 w-48 h-48 bg-gradient-to-r from-purple-600/10 to-blue-600/10 rounded-full blur-2xl -translate-x-1/2 -translate-y-1/2"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16" data-aos="fade-up" data-aos-duration="1000">
          <span className="inline-block text-purple-600 font-semibold mb-2 uppercase tracking-wider text-sm">About Us</span>
          <h2 className="text-4xl sm:text-5xl font-bold text-dark-text mb-4">
            <span className="text-gradient">Who We Are</span>
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-dark-accent to-purple-600 mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-lg text-dark-muted leading-relaxed space-y-6 order-2 lg:order-1">
            <p className="premium-shadow p-6 rounded-xl glass-card bg-gradient-to-br from-purple-500/5 to-blue-500/5" data-aos="fade-right" data-aos-duration="1000">
              <span className="flex items-center mb-3">
                <History className="text-purple-600 h-5 w-5 mr-3" />
                <span className="text-dark-text font-semibold">Our Journey</span>
              </span>
              Finding a tech partner who truly "gets" your vision isn't easy. At GRT Engineering Services Pvt. Ltd., we've spent over 7 years mastering the art of building not just software — but business-ready digital ecosystems that perform, scale, and evolve with you.
            </p>
            
            <p className="premium-shadow p-6 rounded-xl glass-card bg-gradient-to-br from-green-500/5 to-emerald-500/5" data-aos="fade-right" data-aos-delay="200" data-aos-duration="1000">
              <span className="flex items-center mb-3">
                <Users className="text-green-600 h-5 w-5 mr-3" />
                <span className="text-dark-text font-semibold">Our Team</span>
              </span>
              We're not your average development team. We're problem solvers, solution architects, and long-term collaborators who treat every project as our own. From startups validating MVPs to enterprises scaling nationwide, we help turn bold ideas into high-performing, secure, and sustainable digital products.
            </p>
            
            <p className="premium-shadow p-6 rounded-xl glass-card bg-gradient-to-br from-orange-500/5 to-amber-500/5" data-aos="fade-right" data-aos-delay="400" data-aos-duration="1000">
              <span className="flex items-center mb-3">
                <Code2 className="text-orange-600 h-5 w-5 mr-3" />
                <span className="text-dark-text font-semibold">Our Expertise</span>
              </span>
              We're here to help you launch faster, scale smarter, and grow stronger. Whether you have a napkin sketch or detailed wireframes, our team is ready to transform your vision into a market-ready product — with clarity, collaboration, and code that lasts.
            </p>
          </div>
          
          <div className="relative order-1 lg:order-2">
            <div className="relative z-10 card-3d" data-aos="fade-left" data-aos-duration="1300">
              <div className="aspect-square bg-gradient-to-br from-purple-700 to-blue-800 rounded-2xl premium-shadow overflow-hidden relative">
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f')] bg-cover bg-center opacity-60 mix-blend-overlay"></div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#0c0c0e] via-transparent to-transparent"></div>
                <div className="absolute inset-0 flex flex-col justify-end p-8">
                  <h4 className="text-2xl font-bold text-white mb-3">
                    <span className="text-gradient-gold">Your Vision,</span> Our Code
                  </h4>
                  <div className="flex items-center mb-4">
                    <Lightbulb className="text-yellow-400 h-6 w-6 animate-pulse-glow mr-2" />
                    <span className="text-gray-300 font-medium">Turning Ideas into Reality</span>
                  </div>
                  <div className="h-1 w-16 bg-gradient-to-r from-dark-accent to-purple-600 rounded-full"></div>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute top-1/2 left-1/2 w-64 h-64 border border-purple-600/20 rounded-full animate-pulse-glow -z-10 transform -translate-x-1/2 -translate-y-1/2"></div>
            <div className="absolute top-1/2 left-1/2 w-80 h-80 border border-blue-600/10 rounded-full animate-shimmer -z-10 transform -translate-x-1/2 -translate-y-1/2"></div>
            <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-gradient-to-r from-purple-600/10 to-blue-600/10 rounded-full blur-2xl -z-10"></div>
            <div className="absolute bottom-1/4 right-1/4 w-40 h-40 bg-gradient-to-l from-blue-600/10 to-purple-600/10 rounded-full blur-2xl -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About
