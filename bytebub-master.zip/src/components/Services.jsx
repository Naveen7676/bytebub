import { Monitor, Smartphone, Code, Palette, Cloud, Settings, ArrowRight } from 'lucide-react'

const Services = () => {
  return (
    <section id="capabilities" className="py-16 sm:py-20 lg:py-28 relative overflow-hidden mx-4 sm:mx-6 lg:mx-8 mt-16">
      {/* Background elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-blue-500/10 rounded-full blur-2xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16" data-aos="fade-up" data-aos-duration="1200" data-aos-easing="ease-in-out">
          <span className="inline-block text-purple-600 font-semibold mb-2 uppercase tracking-wider text-sm">Our Expertise</span>
          <h2 className="text-4xl sm:text-5xl font-bold text-dark-text mb-4">
            <span className="text-gradient">Premium Services</span>
          </h2>
          <p className="text-dark-muted text-lg max-w-2xl mx-auto mt-4">Delivering exceptional solutions with cutting-edge technology and meticulous attention to detail</p>
          <div className="h-1 w-24 bg-gradient-to-r from-dark-accent to-purple-600 mx-auto rounded-full mt-6"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Web Development */}
          <div className="glass-card p-8 rounded-2xl premium-shadow card-3d flex flex-col h-full hover:scale-[1.02] transition-all duration-300 bg-purple-500/5" 
               data-aos="zoom-in" 
               data-aos-duration="1200" 
               data-aos-delay="200" 
               data-aos-easing="ease-out">
            <div className="bg-purple-500/10 p-4 rounded-xl mb-6 self-start">
              <Monitor className="h-12 w-12 text-purple-600 animate-pulse-glow" />
            </div>
            <h4 className="text-2xl font-semibold text-dark-text mb-4 mt-2">Web Development</h4>
            <p className="text-dark-muted flex-grow">Custom websites, enterprise dashboards, admin portals built with precision and performance.</p>
            <div className="mt-6 pt-4 border-t border-dark-border/20">
              <a href="#contact" className="group inline-flex items-center text-purple-600 font-medium hover:text-purple-600/90 transition-all duration-300">
                Learn more
                <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>
          </div>
          
          {/* Mobile App Development */}
          <div className="glass-card p-8 rounded-2xl premium-shadow card-3d flex flex-col h-full hover:scale-[1.02] transition-all duration-300 bg-green-500/5" 
               data-aos="fade-right" 
               data-aos-duration="1200" 
               data-aos-delay="400" 
               data-aos-easing="ease-out">
            <div className="bg-green-500/10 p-4 rounded-xl mb-6 self-start">
              <Smartphone className="h-12 w-12 text-green-600 animate-pulse-glow" />
            </div>
            <h4 className="text-2xl font-semibold text-dark-text mb-4 mt-2">Mobile App Development</h4>
            <p className="text-dark-muted flex-grow">Cross-platform apps using Flutter for seamless experiences on Android & iOS.</p>
            <div className="mt-6 pt-4 border-t border-dark-border/20">
              <a href="#contact" className="group inline-flex items-center text-green-600 font-medium hover:text-green-600/90 transition-all duration-300">
                Learn more
                <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>
          </div>
          
          {/* Full-Stack Solutions */}
          <div className="glass-card p-8 rounded-2xl premium-shadow card-3d flex flex-col h-full hover:scale-[1.02] transition-all duration-300 bg-orange-500/5" 
               data-aos="fade-left" 
               data-aos-duration="1200" 
               data-aos-delay="600" 
               data-aos-easing="ease-out">
            <div className="bg-orange-500/10 p-4 rounded-xl mb-6 self-start">
              <Code className="h-12 w-12 text-orange-600 animate-pulse-glow" />
            </div>
            <h4 className="text-2xl font-semibold text-dark-text mb-4 mt-2">Full-Stack Solutions</h4>
            <p className="text-dark-muted flex-grow">Robust solutions with MERN Stack, Java Spring Boot, and other leading technologies.</p>
            <div className="mt-6 pt-4 border-t border-dark-border/20">
              <a href="#contact" className="group inline-flex items-center text-orange-600 font-medium hover:text-orange-600/90 transition-all duration-300">
                Learn more
                <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>
          </div>
          
          {/* UI/UX Design */}
          <div className="glass-card p-8 rounded-2xl premium-shadow card-3d flex flex-col h-full hover:scale-[1.02] transition-all duration-300 bg-pink-500/5" 
               data-aos="fade-up" 
               data-aos-duration="1200" 
               data-aos-delay="800" 
               data-aos-easing="ease-out">
            <div className="bg-pink-500/10 p-4 rounded-xl mb-6 self-start">
              <Palette className="h-12 w-12 text-pink-600 animate-pulse-glow" />
            </div>
            <h4 className="text-2xl font-semibold text-dark-text mb-4 mt-2">UI/UX Design</h4>
            <p className="text-dark-muted flex-grow">Crafting user-friendly, responsive interfaces that delight and engage.</p>
            <div className="mt-6 pt-4 border-t border-dark-border/20">
              <a href="#contact" className="group inline-flex items-center text-pink-600 font-medium hover:text-pink-600/90 transition-all duration-300">
                Learn more
                <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>
          </div>
          
          {/* Cloud Deployment & Hosting */}
          <div className="glass-card p-8 rounded-2xl premium-shadow card-3d flex flex-col h-full hover:scale-[1.02] transition-all duration-300 bg-blue-500/5" 
               data-aos="zoom-in-down" 
               data-aos-duration="1200" 
               data-aos-delay="1000" 
               data-aos-easing="ease-out">
            <div className="bg-blue-500/10 p-4 rounded-xl mb-6 self-start">
              <Cloud className="h-12 w-12 text-blue-600 animate-pulse-glow" />
            </div>
            <h4 className="text-2xl font-semibold text-dark-text mb-4 mt-2">Cloud Deployment & Hosting</h4>
            <p className="text-dark-muted flex-grow">Secure and scalable deployment on AWS, Serverbyt, Hostinger, and more.</p>
            <div className="mt-6 pt-4 border-t border-dark-border/20">
              <a href="#contact" className="group inline-flex items-center text-blue-600 font-medium hover:text-blue-600/90 transition-all duration-300">
                Learn more
                <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>
          </div>
          
          {/* Maintenance & AMC Support */}
          <div className="glass-card p-8 rounded-2xl premium-shadow card-3d flex flex-col h-full hover:scale-[1.02] transition-all duration-300 bg-orange-500/5" 
               data-aos="fade-up" 
               data-aos-delay="500" 
               data-aos-duration="1000">
            <div className="bg-gradient-to-br from-[#F59E0B]/10 to-[#F59E0B]/5 p-4 rounded-xl mb-6 self-start">
              <Settings className="h-12 w-12 text-[#F59E0B] animate-pulse-glow" />
            </div>
            <h4 className="text-2xl font-semibold text-dark-text mb-4 mt-2">Maintenance & AMC Support</h4>
            <p className="text-dark-muted flex-grow">Continuous improvements, bug fixes, and system updates to keep your systems running smoothly.</p>
            <div className="mt-6 pt-4 border-t border-dark-border/20">
              <a href="#contact" className="group inline-flex items-center text-dark-accent font-medium hover:text-dark-accent/90 transition-all duration-300">
                Learn more
                <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-16 text-center" data-aos="zoom-in" data-aos-delay="1400" data-aos-duration="1200" data-aos-easing="ease-out">
          <a href="#contact" className="premium-button inline-flex items-center justify-center px-8 py-4 text-base font-medium rounded-xl premium-shadow bg-dark-accent hover:bg-dark-accent/90 text-white transition-all duration-300 ease-in-out transform hover:scale-105 hover-glow">
            <span className="relative z-10">Get Started With Your Project</span>
            <ArrowRight className="ml-3 h-5 w-5 relative z-10" />
          </a>
        </div>
      </div>
    </section>
  )
}

export default Services