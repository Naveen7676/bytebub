import { Twitter, Linkedin, Github, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-dark-primary border-t border-dark-border text-dark-text py-10 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 z-0 bg-animated opacity-10"></div>

      {/* Animated particle effect */}
      <div className="absolute inset-0 z-0">
        {Array.from({ length: 10 }).map((_, index) => (
          <div
            key={index}
            className="absolute rounded-full bg-dark-accent/20 animate-float"
            style={{
              width: `${Math.random() * 6 + 2}px`,
              height: `${Math.random() * 6 + 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${Math.random() * 8 + 5}s`,
            }}
          ></div>
        ))}
      </div>

      {/* Main content */}
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:justify-between md:items-start text-center md:text-left relative z-10 space-y-8 md:space-y-0 md:space-x-8">

        {/* Left: Company Info */}
        <div className="animate-fade-in">
          <div className="flex items-center justify-center md:justify-start mb-2">
            {/* <Heart className="h-4 w-4 text-dark-accent mr-2 animate-pulse-subtle" /> */}
            {/* <p className="text-dark-muted">Made with passion</p> */}
          </div>
        <p className="text-dark-text">
  &copy; {new Date().getFullYear()}{' '}
  <a
    href=""
    target="_blank"
    rel="noopener noreferrer"
    className="underline hover:text-dark-accent transition duration-300"
  >
    ByteBub
  </a>{' '}
  <span className="text-dark-muted">All rights reserved.</span>
</p>

          <p className="text-dark-muted text-sm mt-2">
            <a
              href="/Terms and Conditions – ByteBub-1.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="underline hover:text-dark-accent transition duration-300"
            >
              Terms & Conditions 
            </a>
          </p>
           <p className="text-dark-muted text-sm mt-2">
            <a
              href="/privacy policy.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="underline hover:text-dark-accent transition duration-300"
            >
              Privacy Policy 
            </a>
          </p>
        </div>

        {/* Center: Navigation Links - Two Columns */}
        <div className="grid grid-cols-2 gap-x-10 gap-y-2 justify-center md:justify-start animate-fade-in delay-150">
          {[
            { label: 'Home', href: '#top', delay: 200 },
            { label: 'About Us', href: '#about', delay: 300 },
            { label: 'Services', href: '#capabilities', delay: 400 },
            { label: 'Portfolio', href: '#portfolio', delay: 500 },
            { label: 'Blog', href: '#blog', delay: 600 },
            { label: 'Careers', href: '#careers', delay: 700 },
            { label: 'Contact', href: '#contact', delay: 800 },
          ].map((link, idx) => (
            <a
              key={idx}
              href={link.href}
              className={`text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group hover-lift animate-fade-in delay-${link.delay}`}
            >
              <span>{link.label}</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
            </a>
          ))}
        </div>

        {/* Right: Social Links */}
        <div className="flex justify-center md:justify-end space-x-6 animate-fade-in delay-200">
          <a
            href="#"
            className="text-dark-muted hover:text-dark-accent transition-all duration-300 hover-lift transform hover:scale-110"
          >
            <Twitter className="h-6 w-6" />
          </a>
          <a
            href="https://www.linkedin.com/company/bytebub/?viewAsMember=true"
            className="text-dark-muted hover:text-dark-accent transition-all duration-300 hover-lift transform hover:scale-110"
          >
            <Linkedin className="h-6 w-6" />
          </a>
          <a
            href="#"
            className="text-dark-muted hover:text-dark-accent transition-all duration-300 hover-lift transform hover:scale-110"
          >
            <Github className="h-6 w-6" />
          </a>
        </div>
      </div>

      {/* Bottom text
      <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-dark-border/30 text-center text-dark-muted text-sm animate-fade-in delay-300">
        <p>Designed and developed with excellence</p>
      </div> */}
    </footer>
  );
};

export default Footer;
