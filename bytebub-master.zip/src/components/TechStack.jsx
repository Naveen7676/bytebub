import { LayoutGrid, Server, Database, Smartphone, Figma, Cloud, Award, Sparkles, ChevronRight, Apple } from 'lucide-react'

const TechStack = () => {
  return (
    <section 
      id="skills" 
      className="py-16 sm:py-20 lg:py-24 bg-gradient-to-br from-[#1a1a2e] to-[#16213e] rounded-lg shadow-lg border border-dark-border/20 mx-4 sm:mx-6 lg:mx-8 mt-8 relative overflow-hidden"
      data-aos="fade-up"
      data-aos-duration="1200"
      data-aos-easing="ease-in-out"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative z-10">
          <h3 className="text-3xl sm:text-4xl font-bold text-white text-center mb-12">Our Tech Stack</h3>
          <div className="absolute -top-20 -left-20 w-52 h-52 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-glow-up"></div>
          <div className="absolute -top-30 -right-30 w-40 h-40 bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-full blur-2xl animate-glow-down"></div>
          <div className="absolute -bottom-20 -left-30 w-40 h-40 bg-gradient-to-br from-teal-500/20 to-cyan-500/20 rounded-full blur-2xl animate-glow-up"></div>
          <div className="absolute -bottom-30 -right-20 w-52 h-52 bg-gradient-to-br from-amber-500/20 to-yellow-500/20 rounded-full blur-2xl animate-glow-down"></div>
          <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-glow-down"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div 
            className="bg-dark-card p-6 rounded-xl shadow-md border border-dark-border flex flex-col items-center text-center"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="200"
            data-aos-easing="ease-out"
          >
            <div className="w-full h-20 mb-4 relative">
              <LayoutGrid className="h-12 w-12 text-purple-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-purple-600/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <h4 className="text-xl font-semibold text-dark-text mb-3">Frontend</h4>
            <ul className="text-dark-muted space-y-2">
              <li className="flex items-center"><LayoutGrid className="h-4 w-4 mr-2 text-dark-highlight" />React.js</li>
              <li className="flex items-center"><LayoutGrid className="h-4 w-4 mr-2 text-dark-highlight" />Tailwind CSS</li>
              <li className="flex items-center"><LayoutGrid className="h-4 w-4 mr-2 text-dark-highlight" />HTML5</li>
              <li className="flex items-center"><LayoutGrid className="h-4 w-4 mr-2 text-dark-highlight" />CSS3</li>
            </ul>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-md border border-dark-border flex flex-col items-center text-center"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="400"
            data-aos-easing="ease-out"
          >
            <div className="w-full h-20 mb-4 relative">
              <Server className="h-12 w-12 text-blue-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <h4 className="text-xl font-semibold text-dark-text mb-3">Backend</h4>
            <ul className="text-dark-muted space-y-2">
              <li className="flex items-center"><Award className="h-4 w-4 mr-2 text-dark-highlight" />Node.js</li>
              <li className="flex items-center"><Award className="h-4 w-4 mr-2 text-dark-highlight" />Java Spring Boot</li>
              <li className="flex items-center"><Award className="h-4 w-4 mr-2 text-dark-highlight" />Java EE</li>
            </ul>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-md border border-dark-border flex flex-col items-center text-center"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="600"
            data-aos-easing="ease-out"
          >
            <div className="w-full h-20 mb-4 relative">
              <Database className="h-12 w-12 text-purple-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-purple-600/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <h4 className="text-xl font-semibold text-dark-text mb-3">Databases</h4>
            <ul className="text-dark-muted space-y-2">
              <li className="flex items-center"><Database className="h-4 w-4 mr-2 text-dark-highlight" />MongoDB</li>
              <li className="flex items-center"><Database className="h-4 w-4 mr-2 text-dark-highlight" />MySQL</li>
              <li className="flex items-center"><Database className="h-4 w-4 mr-2 text-dark-highlight" />SQL</li>
            </ul>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-md border border-dark-border flex flex-col items-center text-center"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="800"
            data-aos-easing="ease-out"
          >
            <div className="w-full h-20 mb-4 relative">
              <Smartphone className="h-12 w-12 text-blue-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <h4 className="text-xl font-semibold text-dark-text mb-3">Mobile</h4>
            <ul className="text-dark-muted space-y-2">
              <li className="flex items-center"><Smartphone className="h-4 w-4 mr-2 text-dark-highlight" />Flutter (Android & iOS)</li>
            </ul>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-md border border-dark-border flex flex-col items-center text-center"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="1000"
            data-aos-easing="ease-out"
          >
            <div className="w-full h-20 mb-4 relative">
              <Figma className="h-12 w-12 text-purple-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-purple-600/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <h4 className="text-xl font-semibold text-dark-text mb-3">Design</h4>
            <ul className="text-dark-muted space-y-2">
              <li className="flex items-center"><Figma className="h-4 w-4 mr-2 text-dark-highlight" />Custom UI/UX</li>
              <li className="flex items-center"><Smartphone className="h-4 w-4 mr-2 text-dark-highlight" />Responsive Design Principles</li>
            </ul>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-md border border-dark-border flex flex-col items-center text-center"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="1200"
            data-aos-easing="ease-out"
          >
            <div className="w-full h-20 mb-4 relative">
              <Cloud className="h-12 w-12 text-blue-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-xl blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <h4 className="text-xl font-semibold text-dark-text mb-3">Cloud & Deployment</h4>
            <ul className="text-dark-muted space-y-2">
              <li className="flex items-center"><Cloud className="h-4 w-4 mr-2 text-dark-highlight" />AWS</li>
              <li className="flex items-center"><Server className="h-4 w-4 mr-2 text-dark-highlight" />Serverbyt</li>
              <li className="flex items-center"><Server className="h-4 w-4 mr-2 text-dark-highlight" />Hostinger</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

export default TechStack
