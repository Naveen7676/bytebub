import { Mail, Sparkles, Code, Zap, Shield, Star } from 'lucide-react';
import { useEffect, useState } from 'react';

const Hero = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <section className="relative bg-dark-primary text-dark-text py-20 sm:py-24 lg:py-32 overflow-hidden border-b border-dark-border">
      {/* Premium Animated Background */}
      <div className="absolute inset-0 z-0 bg-animated opacity-10"></div>
      
      {/* Animated particles with enhanced glow */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {Array.from({ length: 30 }).map((_, index) => (
          <div 
            key={index}
            className="absolute rounded-full bg-dark-accent/30 float"
            data-aos="fade-in"
            data-aos-delay={index * 50}
            data-aos-duration="2000"
            style={{
              width: `${Math.random() * 12 + 5}px`,
              height: `${Math.random() * 12 + 5}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              boxShadow: `0 0 ${Math.random() * 10 + 5}px rgba(139, 92, 246, ${Math.random() * 0.3 + 0.1})`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${Math.random() * 10 + 10}s`,
            }}
          ></div>
        ))}
      </div>
      
      {/* Enhanced geometric shapes with premium effects */}
      <div className="absolute w-40 h-40 border border-dark-accent/20 rounded-full animate-shimmer" 
           data-aos="fade-in"
           data-aos-duration="1500"
           style={{ top: '10%', right: '15%', opacity: 0.6 }}></div>
           
      <div className="absolute w-60 h-60 border border-dark-highlight/20 rounded-full animate-pulse-glow" 
           data-aos="fade-in" 
           data-aos-delay="300"
           data-aos-duration="1500"
           style={{ bottom: '5%', left: '10%', opacity: 0.5 }}></div>
           
      <div className="absolute w-32 h-32 border border-dark-accent/30 rotate-45 float" 
           data-aos="fade-in" 
           data-aos-delay="600"
           data-aos-duration="1500"
           style={{ top: '30%', left: '5%', opacity: 0.3 }}></div>
           
      <div className="absolute w-20 h-20 border-2 border-dark-accent/30 rounded-full animate-shimmer" 
           data-aos="fade-in" 
           data-aos-delay="900"
           data-aos-duration="1500"
           style={{ bottom: '20%', right: '8%', opacity: 0.4 }}></div>

      {/* Hero Content with Premium Styling */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="flex justify-center mb-4" data-aos="fade-down" data-aos-duration="1000">
            <Sparkles className="text-dark-accent h-12 w-12 animate-pulse-glow" />
        </div>
        
     <h2
  className="font-playfair text-4xl sm:text-5xl lg:text-7xl font-bold leading-tight mb-8 text-white"
  data-aos="fade-up"
  data-aos-duration="1000"
>
  <span className="block">As good as an in-house team.</span>
  <span className="block">From Local Ideas to Global Platforms.</span>
</h2>
        <div className="flex flex-wrap justify-center gap-8 mb-12" data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
          <div className="flex items-center space-x-2 hover-lift glass-card px-4 py-2 rounded-xl">
            <Zap className="text-dark-accent h-6 w-6" />
            <span className="text-dark-accent font-medium">Lightning Fast</span>
          </div>
          <div className="flex items-center space-x-2 hover-lift glass-card px-4 py-2 rounded-xl">
            <Code className="text-dark-highlight h-6 w-6" />
            <span className="text-dark-highlight font-medium">Clean Code</span>
          </div>
          <div className="flex items-center space-x-2 hover-lift glass-card px-4 py-2 rounded-xl">
            <Shield className="text-dark-accent h-6 w-6" />
            <span className="text-dark-accent font-medium">Rock-Solid Security</span>
          </div>
        </div>
        
        <p className="text-lg sm:text-xl lg:text-2xl mb-8 text-dark-text" data-aos="fade-up" data-aos-delay="600" data-aos-duration="1000">
          From groundbreaking web platforms to intuitive mobile apps, 
          <br className="hidden md:block" />
          we engineer robust, scalable, and secure software that drives innovation.
        </p>
        
        <p className="text-md sm:text-lg lg:text-xl mb-12 text-dark-muted" data-aos="fade-up" data-aos-delay="700" data-aos-duration="1000">
          Your vision, our expertise: <span className="text-dark-accent">Let's build the <span className="text-gradient-gold">future</span>, together.</span>
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center gap-6" data-aos="fade-up" data-aos-delay="800" data-aos-duration="1000">
          <a
            href="#contact"
            className="premium-button inline-flex items-center justify-center px-8 py-4 text-base font-medium rounded-xl premium-shadow bg-dark-accent hover:bg-dark-accent/90 text-white transition-all duration-300 ease-in-out transform hover:scale-105 hover-glow relative overflow-hidden"
          >
            <span className="relative z-10">Get a Free Consultation</span>
            <Mail className="ml-3 h-5 w-5 relative z-10" />
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-dark-accent via-purple-600 to-dark-accent bg-size-200 bg-pos-0 transition-all duration-500 group-hover:bg-pos-100"></span>
          </a>
          
          <a
            href="#portfolio"
            className="premium-button inline-flex items-center justify-center px-8 py-4 border-2 border-dark-accent text-base font-medium rounded-xl text-dark-accent hover:text-white hover:bg-dark-accent/20 transition-all duration-300 ease-in-out hover-glow"
          >
            <Star className="mr-2 h-5 w-5" />
            View Our Work
          </a>
        </div>
        
        {/* Curved design element */}
        <div className="absolute bottom-0 left-0 right-0 h-16 overflow-hidden" data-aos="fade-up" data-aos-duration="1000">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="absolute bottom-0 w-full h-full">
            <path fill="rgba(139, 92, 246, 0.1)" fillOpacity="1" d="M0,192L60,165.3C120,139,240,85,360,90.7C480,96,600,160,720,170.7C840,181,960,139,1080,128C1200,117,1320,139,1380,149.3L1440,160L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z"></path>
          </svg>
        </div>
      </div>
    </section>
  );
};

export default Hero;