import { Mail, Phone, MapPin } from 'lucide-react'

const Contact = () => {
  return (
    <section id="contact" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-br from-[#1a1a2e] to-[#16213e] rounded-lg shadow-md border border-dark-border mx-4 sm:mx-6 lg:mx-8 mt-8 mb-8 relative overflow-hidden animate-fade-in">
      {/* Animated Background Elements */}
      <div className="absolute -top-32 -left-32 w-64 h-64 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-glow-up"></div>
      <div className="absolute -top-40 -right-40 w-52 h-52 bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-full blur-2xl animate-glow-down"></div>
      <div className="absolute -bottom-40 -left-40 w-52 h-52 bg-gradient-to-br from-teal-500/20 to-cyan-500/20 rounded-full blur-2xl animate-glow-up"></div>
      <div className="absolute -bottom-32 -right-32 w-64 h-64 bg-gradient-to-br from-amber-500/20 to-yellow-500/20 rounded-full blur-2xl animate-glow-down"></div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h3 className="text-3xl sm:text-4xl font-bold mb-8 text-white bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">Get in Touch</h3>
        <p className="text-lg mb-10 text-gray-300">
          Ready to start your next project? Contact us today for a free consultation!
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-8">
          <a href="mailto:hr.bytebub@grtengg.co.in" className="flex items-center space-x-3 text-white hover:text-purple-400 transition duration-300 group">
            <Mail className="h-6 w-6" />
            <span>contact.bytebub@grtengg.co.in</span>
          </a>
          <a href="tel:+1234567890" className="flex items-center space-x-3 text-white hover:text-blue-400 transition duration-300 group">
            <Phone className="h-6 w-6" />
            <span>+91-8073343628</span>
          </a>
          <div className="flex items-center space-x-3 text-gray-300">
            <MapPin className="h-6 w-6" />
            <span>Bengaluru, India</span>
          </div>
        </div>
        <div className="mt-12 max-w-xl mx-auto">
          <form className="space-y-6">
            <div>
              <input
                type="text"
                placeholder="Your Name"
                className="w-full px-4 py-3 rounded-lg bg-dark-card text-dark-text border border-dark-border placeholder-dark-muted focus:outline-none focus:ring-2 focus:ring-dark-accent"
              />
            </div>
            <div>
              <input
                type="email"
                placeholder="Your Email"
                className="w-full px-4 py-3 rounded-lg bg-dark-card text-dark-text border border-dark-border placeholder-dark-muted focus:outline-none focus:ring-2 focus:ring-dark-accent"
              />
            </div>
            <div>
              <textarea
                placeholder="Your Message"
                rows="5"
                className="w-full px-4 py-3 rounded-lg bg-dark-card text-dark-text border border-dark-border placeholder-dark-muted focus:outline-none focus:ring-2 focus:ring-dark-accent"
              ></textarea>
            </div>
            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-purple-500 to-blue-500 text-white font-medium rounded-full shadow-lg hover:opacity-90 transition duration-300 ease-in-out transform hover:scale-105"
            >
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  )
}

export default Contact