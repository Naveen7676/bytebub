// src/components/CareersPage.jsx
import React, { useState, useEffect } from 'react';
import HeroSection from './HeroSection';
import JobListings from './JobListings';
import jobsData from '../../data/jobs.json'; // Importing local job data
import './CareersPage.css'; // Component-specific styles

function Careers() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // In a real application, you'd fetch this from a backend API:
    // fetch('/api/jobs')
    //   .then(response => {
    //     if (!response.ok) {
    //       throw new Error(`HTTP error! status: ${response.status}`);
    //     }
    //     return response.json();
    //   })
    //   .then(data => {
    //     setJobs(data);
    //     setLoading(false);
    //   })
    //   .catch(error => {
    //     setError(error);
    //     setLoading(false);
    //   });

    // For this example, we'll use the local JSON data directly
    try {
      setJobs(jobsData);
      setLoading(false);
    } catch (err) {
      setError(err);
      setLoading(false);
    }
  }, []);

  if (loading) {
    return <div className="careers-status">Loading job openings...</div>;
  }

  if (error) {
    return <div className="careers-status error">Error: {error.message}. Please try again later.</div>;
  }

  return (
    <div id="careers" className="careers-page-container bg-dark-secondary text-dark-text">
      <HeroSection
        title="Join Our Team"
        subtitle="Innovate, grow, and make an impact with us. Explore exciting career opportunities."
      />
      <JobListings jobs={jobs} />

      {/* Tech Stack Section */}
      {/* <section className="careers-info-section bg-dark-card border border-dark-border">
        <h2 className="text-dark-text">Tech Stack</h2>
        <ul>
          <li>React & Next.js</li>
          <li>Node.js & Express</li>
          <li>MongoDB & PostgreSQL</li>
          <li>RESTful APIs & GraphQL</li>
          <li>CI/CD & Docker</li>
          <li>Agile Methodologies</li>
        </ul>
      </section> */}

      
      <section className="careers-info-section bg-dark-card border border-dark-border">
        <h2 className="text-dark-text">Why Work With Us?</h2>
        <p className="text-dark-muted">
          We believe in fostering a collaborative and supportive environment where
          everyone can thrive. We offer competitive benefits, opportunities for
          professional development, and a culture that values innovation and
          diversity.
        </p>
        <p className="text-dark-muted">
          If you're passionate about what you do and eager to make a difference,
          we'd love to hear from you!
        </p>
      </section>
    </div>
  );
}

export default Careers;
