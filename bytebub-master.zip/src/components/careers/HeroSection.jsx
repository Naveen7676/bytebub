// src/components/HeroSection.jsx
import React from 'react';

function HeroSection({ title, subtitle }) {
  return (
    <section className="hero-section relative overflow-hidden h-[50vh] flex items-center justify-center px-4 sm:px-6 lg:px-8">
      {/* Team Image Overlay */}
      <div className="absolute inset-0 w-full h-full bg-cover bg-center opacity-30 animate-fade-in">
        <img
          src="/images/team.jpg"
          alt="Diverse team working together"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Background Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-dark-secondary/80 to-dark-secondary/90 opacity-90"></div>

      {/* Animated Background Elements */}
      <div className="absolute -top-12 -left-12 w-36 h-36 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-glow-up"></div>
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-full blur-2xl animate-glow-down"></div>
      <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-gradient-to-br from-teal-500/20 to-cyan-500/20 rounded-full blur-2xl animate-glow-up"></div>
      <div className="absolute -bottom-12 -right-12 w-36 h-36 bg-gradient-to-br from-amber-500/20 to-yellow-500/20 rounded-full blur-2xl animate-glow-down"></div>

      <div className="hero-content relative z-10 text-center">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent mb-4 sm:mb-6 animate-fade-in">
          {title}
        </h1>
        <p className="text-lg sm:text-xl text-gray-300 max-w-xl mx-auto animate-fade-in">
          {subtitle}
        </p>
        <div className="absolute -top-2 -left-2 w-10 h-10 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div>
      </div>
    </section>
  );
}

export default HeroSection;