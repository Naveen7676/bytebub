import React, { useState } from 'react';
import './JobListings.css';
import { ChevronRight } from 'lucide-react';

function JobListings({ jobs }) {
  const [expandedJobs, setExpandedJobs] = useState([]);

  const toggleExpand = (jobId) => {
    setExpandedJobs((prevExpanded) =>
      prevExpanded.includes(jobId)
        ? prevExpanded.filter((id) => id !== jobId)
        : [...prevExpanded, jobId]
    );
  };

  return (
    <section
      className="job-listings-section"
      data-aos="fade-up"
      data-aos-duration="1200"
      data-aos-easing="ease-in-out"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl sm:text-4xl font-bold text-dark-text text-center mb-12">
          Current Job Openings
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {jobs.length > 0 ? (
            jobs.map((job, index) => {
              const isExpanded = expandedJobs.includes(job.id);
              const displayedRequirements = isExpanded
                ? job.requirements
                : job.requirements.slice(0, 3);

              return (
                <div
                  key={job.id}
                  className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
                  data-aos="zoom-in"
                  data-aos-duration="1200"
                  data-aos-delay={`${(index + 1) * 200}`}
                  data-aos-easing="ease-out"
                >
                  <h3>{job.title}</h3>
                  <p className="job-meta">
                    {job.department} | {job.location} | {job.type}
                  </p>
                  <p className="job-description">
                    {job.description.substring(0, 150)}...
                  </p>

                  <div className="job-requirements mt-3">
                    <h4>Key Requirements:</h4>
                    <ul>
                      {displayedRequirements.map((req, i) => (
                        <li key={i}>{req}</li>
                      ))}
                      {job.requirements.length > 3 && (
                        <li>
                          <button
                            className="text-blue-500 underline text-sm"
                            onClick={() => toggleExpand(job.id)}
                          >
                            {isExpanded ? 'Show less' : '...and more!'}
                          </button>
                        </li>
                      )}
                    </ul>
                  </div>

                  {/* <a
                    href={job.applyLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="apply-button inline-block mt-4 px-4 py-2 bg-dark-primary text-dark-text rounded hover:bg-dark-accent/20 transition"
                  >
                    Apply Now
                    <ChevronRight className="inline ml-2 w-4 h-4" />
                  </a> */}

                       <a
                    href={`mailto:hr.bytebub@grtengg.co.in?subject=Application for ${encodeURIComponent(
                      job.title
                    )}`}
                    className="apply-button inline-block mt-4 px-4 py-2 bg-dark-primary text-dark-text rounded hover:bg-dark-accent/20 transition"
                  >
                    Apply Now
                    <ChevronRight className="inline ml-2 w-4 h-4" />
                  </a>
                  
                </div>
              );
            })
          ) : (
            <p className="text-center text-dark-muted mt-8">
              No job openings at the moment. Please check back later!
            </p>
          )}
        </div>
      </div>
    </section>
  );
}

export default JobListings;
