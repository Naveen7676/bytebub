// src/components/JobCard.jsx
import React from 'react';
import './JobCard.css'; // Component-specific styles

function JobCard({ job }) {
  return (
    <div className="job-card">
      <h3>{job.title}</h3>
      <p className="job-meta">
        {job.department} | {job.location} | {job.type}
      </p>
      <p className="job-description">
        {job.description.substring(0, 150)}... {/* Display a truncated description */}
      </p>
      <div className="job-requirements">
        <h4>Key Requirements:</h4>
        <ul>
          {job.requirements.slice(0, 3).map((req, index) => ( // Show first 3 requirements
            <li key={index}>{req}</li>
          ))}
          {job.requirements.length > 3 && <li>...and more!</li>}
        </ul>
      </div>
      <a href={job.applyLink} target="_blank" rel="noopener noreferrer" className="apply-button">
        Apply Now
      </a>
      
      {/* In a real app, you might have a "View Details" button linking to a dedicated page */}
    </div>
  );
}

export default JobCard;