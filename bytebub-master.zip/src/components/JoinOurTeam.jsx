import { Briefcase, Users, MapPin, Clock, ChevronRight, Sparkles } from 'lucide-react';

// Sample Job Data (add more as needed)
const jobs = [
  {
    title: "Senior Software Engineer",
    location: "Remote",
    type: "Full-time",
    experience: "5+ Years",
    description: "Develop and maintain scalable software solutions. Collaborate with cross-functional teams.",
  },
  {
    title: "UI/UX Designer",
    location: "New York, USA",
    type: "Full-time",
    experience: "3+ Years",
    description: "Create intuitive and visually appealing user interfaces for our products.",
  },
  {
    title: "Marketing Specialist",
    location: "London, UK",
    type: "Full-time",
    experience: "2+ Years",
    description: "Plan and execute marketing campaigns to drive brand awareness and lead generation.",
  },
];

const JobCard = ({ title, location, type, experience, description }) => {
  return (
    <div className="relative bg-gray-800/90 p-6 rounded-2xl shadow-lg border border-gray-700 hover:shadow-xl transition-all duration-300 ease-in-out transform hover:-translate-y-2 hover:scale-[1.01] group overflow-hidden">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold text-white bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">{title}</h3>
        <div className="flex items-center gap-2">
          <Briefcase className="h-6 w-6 text-white transition-transform duration-300 group-hover:scale-110" />
          <Sparkles className="h-4 w-4 text-purple-500 animate-pulse" />
          {/* Consider removing these absolute positioned elements from inside JobCard if they are meant for the overall section */}
          {/* <div className="absolute -top-2 -right-2 w-12 h-12 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div> */}
        </div>
      </div>
      <div className="flex flex-wrap gap-4 mb-4">
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-purple-500 transition-transform duration-300 group-hover:scale-110" />
          <span className="text-sm text-purple-300">{location}</span>
          {/* <div className="absolute -top-2 -left-2 w-12 h-12 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div> */}
        </div>
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-blue-500 transition-transform duration-300 group-hover:scale-110" />
          <span className="text-sm text-blue-300">{type}</span>
          {/* <div className="absolute -top-2 -right-2 w-12 h-12 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-full blur-2xl animate-float"></div> */}
        </div>
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-amber-500 transition-transform duration-300 group-hover:scale-110" />
          <span className="text-sm text-amber-300">{experience}</span>
          {/* <div className="absolute -top-2 -left-2 w-12 h-12 bg-gradient-to-br from-amber-500/20 to-yellow-500/20 rounded-full blur-2xl animate-float"></div> */}
        </div>
      </div>

      <p className="text-gray-300 mb-4 animate-fade-in">{description}</p>

      <a
        href="#"
        className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg text-white font-medium hover:opacity-90 transition duration-300 relative overflow-hidden"
      >
        <span className="mr-2">Apply Now</span>
        <ChevronRight className="h-4 w-4" />
        {/* <div className="absolute -top-2 -right-2 w-12 h-12 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div> */}
      </a>
    </div>
  );
};

const JoinOurTeam = () => {
  return (
    <section id="careers" className="py-16 sm:py-20 lg:py-24 bg-gradient-to-br from-[#1a1a2e] to-[#16213e] overflow-hidden animate-fade-in relative">
      {/* Animated Background Elements */}
      <div className="absolute -top-32 -left-32 w-64 h-64 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-glow-up"></div>
      <div className="absolute -top-40 -right-40 w-52 h-52 bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-full blur-2xl animate-glow-down"></div>
      <div className="absolute -bottom-40 -left-40 w-52 h-52 bg-gradient-to-br from-teal-500/20 to-cyan-500/20 rounded-full blur-2xl animate-glow-up"></div>
      <div className="absolute -bottom-32 -right-32 w-64 h-64 bg-gradient-to-br from-amber-500/20 to-yellow-500/20 rounded-full blur-2xl animate-glow-down"></div>

      {/* Colorful Gradient Particles */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-12 -left-12 w-40 h-40 bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-full blur-2xl animate-float"></div>
        <div className="absolute -top-16 -right-16 w-40 h-40 bg-gradient-to-br from-pink-500/10 to-orange-500/10 rounded-full blur-2xl animate-float"></div>
        <div className="absolute -bottom-12 -left-16 w-40 h-40 bg-gradient-to-br from-teal-500/10 to-cyan-500/10 rounded-full blur-2xl animate-float"></div>
        <div className="absolute -bottom-16 -right-12 w-40 h-40 bg-gradient-to-br from-amber-500/10 to-yellow-500/10 rounded-full blur-2xl animate-float"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 relative">
          <h2 className="text-4xl sm:text-5xl font-bold mb-8 text-white bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">Join Our Team</h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">We're looking for talented individuals to join our growing team. Explore our current openings and apply today!</p>
          <div className="absolute -top-2 -left-2 w-16 h-16 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {jobs.map((job, index) => (
            <div key={index} className="relative overflow-hidden">
              {/* These floating elements around the JobCard should likely be within the JobCard itself or handled differently for better visual consistency */}
              {/* <div className="absolute -top-4 -left-4 w-12 h-12 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div>
              <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-br from-pink-500/20 to-orange-500/20 rounded-full blur-2xl animate-float"></div>
              <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-gradient-to-br from-teal-500/20 to-cyan-500/20 rounded-full blur-2xl animate-float"></div>
              <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-gradient-to-br from-amber-500/20 to-yellow-500/20 rounded-full blur-2xl animate-float"></div> */}
              <JobCard
                title={job.title}
                location={job.location}
                type={job.type}
                experience={job.experience}
                description={job.description}
              />
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href="#contact"
            className="inline-flex items-center px-8 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition duration-300 animate-fade-in"
          >
            Contact Us for Other Positions
          </a>
        </div>
      </div>
    </section>
  );
};

export default JoinOurTeam;