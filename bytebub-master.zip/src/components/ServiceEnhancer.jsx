// import { useState } from 'react'
// import { Feather } from 'lucide-react'

// const ServiceEnhancer = () => {
//   const [serviceDescriptionInput, setServiceDescriptionInput] = useState('')
//   const [enhancedServiceDescription, setEnhancedServiceDescription] = useState('')
//   const [isLoadingServiceEnhancer, setIsLoadingServiceEnhancer] = useState(false)
//   const [serviceEnhancerError, setServiceEnhancerError] = useState('')

//   const enhanceServiceDescription = async () => {
//     setIsLoadingServiceEnhancer(true)
//     setEnhancedServiceDescription('')
//     setServiceEnhancerError('')

//     const prompt = `Expand the following brief service description into a more detailed, professional, and marketing-friendly paragraph. Focus on benefits and value proposition for a tech company.

// Brief Service Description: ${serviceDescriptionInput}

// Enhanced Description:`

//     let chatHistory = []
//     chatHistory.push({ role: "user", parts: [{ text: prompt }] })

//     const payload = { contents: chatHistory }
//     const apiKey = "AIzaSyBvo6ALE8jLzfY7xoSAD9zx9Ws5_35-LM4" // Replace with your actual API key
//     const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`

//     try {
//       const response = await fetch(apiUrl, {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(payload)
//       })

//       if (!response.ok) {
//         const errorData = await response.json()
//         throw new Error(`API error: ${response.status} ${response.statusText} - ${errorData.error?.message || 'Unknown error'}`)
//       }

//       const result = await response.json()

//       if (result.candidates && result.candidates.length > 0 &&
//           result.candidates[0].content && result.candidates[0].content.parts &&
//           result.candidates[0].content.parts.length > 0) {
//         const text = result.candidates[0].content.parts[0].text
//         setEnhancedServiceDescription(text)
//       } else {
//         setEnhancedServiceDescription('Could not enhance the description. Please try a different input.')
//       }
//     } catch (err) {
//       console.error("Error enhancing service description:", err)
//       setServiceEnhancerError(`Failed to enhance description: ${err.message}. Please try again.`)
//     } finally {
//       setIsLoadingServiceEnhancer(false)
//     }
//   }

//   return (
//     <section id="service-enhancer" className="py-16 sm:py-20 lg:py-24 bg-gray-100 rounded-lg shadow-md mx-4 sm:mx-6 lg:mx-8 mt-8">
//       <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
//         <h3 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-8">✨ Enhance Your Service Description ✨</h3>
//         <p className="text-lg mb-8 text-gray-700 opacity-90">
//           Provide a brief description of a service, and our AI will expand it into a detailed, professional, and marketing-friendly paragraph.
//         </p>
//         <div className="space-y-6">
//           <textarea
//             className="w-full px-4 py-3 rounded-lg bg-white text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-800 resize-y min-h-[120px]"
//             placeholder="e.g., 'We build custom websites.' or 'Mobile app development for startups.'"
//             value={serviceDescriptionInput}
//             onChange={(e) => setServiceDescriptionInput(e.target.value)}
//             rows="5"
//           ></textarea>
//           <button
//             onClick={enhanceServiceDescription}
//             disabled={isLoadingServiceEnhancer || !serviceDescriptionInput.trim()}
//             className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-medium rounded-full shadow-lg text-white bg-blue-900 hover:bg-blue-700 transition duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
//           >
//             {isLoadingServiceEnhancer ? (
//               <>
//                 <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
//                   <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
//                   <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
//                 </svg>
//                 Enhancing...
//               </>
//             ) : (
//               <>
//                 Enhance Description ✨
//                 <Feather className="ml-3 h-5 w-5" />
//               </>
//             )}
//           </button>

//           {serviceEnhancerError && (
//             <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative mt-4" role="alert">
//               <span className="block sm:inline">{serviceEnhancerError}</span>
//             </div>
//           )}

//           {enhancedServiceDescription && (
//             <div className="mt-8 p-6 bg-white text-gray-800 rounded-xl shadow-lg text-left whitespace-pre-wrap">
//               <h4 className="text-xl font-semibold mb-4 text-gray-900">Enhanced Description:</h4>
//               <p>{enhancedServiceDescription}</p>
//             </div>
//           )}
//         </div>
//       </div>
//     </section>
//   )
// }

// export default ServiceEnhancer