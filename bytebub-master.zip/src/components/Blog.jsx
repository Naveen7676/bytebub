import { Mail } from 'lucide-react'

const Blog = () => {
  return (
    <section 
      id="blog" 
      className="py-16 sm:py-20 lg:py-24 bg-dark-secondary rounded-lg shadow-md border border-dark-border mx-4 sm:mx-6 lg:mx-8 mt-8"
      data-aos="fade-up"
      data-aos-duration="1200"
      data-aos-easing="ease-in-out"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h3 className="text-3xl sm:text-4xl font-bold text-dark-text mb-8">Our Blogs</h3>
        <p className="text-lg text-dark-muted mb-12">Stay updated with our latest insights, articles, and company news.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="200"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Mastering Serverless Architectures: A Deep Dive for Modern Engineers</h4>
            <p className="text-sm text-dark-muted mb-4 animate-slide-up">Aug 15, 2024 • Rohan Desai</p>
            <p className="text-dark-muted mb-4">Explore the nuances of serverless computing, its benefits, challenges, and best practices for implementation with AWS Lambda and Azure Functions.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-dark-accent/20 text-dark-accent text-xs font-medium px-2.5 py-0.5 rounded-full">Serverless</span>
              <span className="bg-dark-highlight/20 text-dark-highlight text-xs font-medium px-2.5 py-0.5 rounded-full">Cloud Architecture</span>
              <span className="bg-amber-700/20 text-amber-400 text-xs font-medium px-2.5 py-0.5 rounded-full">AWS</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">Read More &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="400"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">The Evolution of UI/UX in the AI Era: Designing for Intelligent Systems</h4>
            <p className="text-sm text-dark-muted mb-4 animate-slide-up">Jun 28, 2024 • Vikram Choudhary</p>
            <p className="text-dark-muted mb-4">How AI is reshaping user interfaces and experiences, focusing on personalization, conversational UIs, and ethical design considerations.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-purple-900/20 text-purple-400 text-xs font-medium px-2.5 py-0.5 rounded-full">UI/UX</span>
              <span className="bg-red-900/20 text-red-400 text-xs font-medium px-2.5 py-0.5 rounded-full">AI</span>
              <span className="bg-indigo-900/20 text-indigo-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Design Thinking</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">Read More &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="600"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Building Resilient Microservices with Java Spring Boot and Netflix OSS</h4>
            <p className="text-sm text-dark-muted mb-4 animate-slide-up">May 10, 2024 • Aarav Sharma</p>
            <p className="text-dark-muted mb-4">A comprehensive guide to developing robust microservices, covering patterns like circuit breakers, service discovery, and distributed tracing.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-orange-900/20 text-orange-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Microservices</span>
              <span className="bg-teal-900/20 text-teal-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Java Spring Boot</span>
              <span className="bg-pink-900/20 text-pink-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Software Architecture</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">Read More &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="800"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Unlocking the Future: The Power of AI</h4>
            <p className="text-sm text-dark-muted mb-4 animate-slide-up">Aug 15, 2024 • Rohan Desai</p>
            <div className="relative">
              <p className="text-dark-muted mb-4 animate-slide-up">Artificial intelligence (AI) is transforming industries by enabling machines to learn, reason, and make decisions like humans. AI algorithms can analyze vast amounts of data, recognize patterns, and even generate new insights, unlocking opportunities in fields like healthcare, finance, and automation. As AI continues to advance, it's becoming an essential part of modern innovation.</p>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-dark-accent/20 text-dark-accent text-xs font-medium px-2.5 py-0.5 rounded-full">Serverless</span>
              <span className="bg-dark-highlight/20 text-dark-highlight text-xs font-medium px-2.5 py-0.5 rounded-full">AI</span>
              <span className="bg-amber-700/20 text-amber-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Agentic web</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">Read More &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="1000"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Mastering Serverless Architectures: A Deep Dive for Modern Engineers</h4>
            <p className="text-sm text-dark-muted mb-4 animate-slide-up">Aug 15, 2024 • Rohan Desai</p>
            <p className="text-dark-muted mb-4">Explore the nuances of serverless computing, its benefits, challenges, and best practices for implementation with AWS Lambda and Azure Functions.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-dark-accent/20 text-dark-accent text-xs font-medium px-2.5 py-0.5 rounded-full">Serverless</span>
              <span className="bg-dark-highlight/20 text-dark-highlight text-xs font-medium px-2.5 py-0.5 rounded-full">Cloud Architecture</span>
              <span className="bg-amber-700/20 text-amber-400 text-xs font-medium px-2.5 py-0.5 rounded-full">AWS</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">Read More &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="1200"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">The Evolution of UI/UX in the AI Era: Designing for Intelligent Systems</h4>
            <p className="text-sm text-dark-muted mb-4 animate-slide-up">Jun 28, 2024 • Vikram Choudhary</p>
            <p className="text-dark-muted mb-4">How AI is reshaping user interfaces and experiences, focusing on personalization, conversational UIs, and ethical design considerations.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-purple-900/20 text-purple-400 text-xs font-medium px-2.5 py-0.5 rounded-full">UI/UX</span>
              <span className="bg-red-900/20 text-red-400 text-xs font-medium px-2.5 py-0.5 rounded-full">AI</span>
              <span className="bg-indigo-900/20 text-indigo-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Design Thinking</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">Read More &rarr;</a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Blog
