// import { useState, useEffect } from 'react'
// import { Menu, X, MoonStar } from 'lucide-react'
// import logo from '../assets/logo6.png'

// const Header = () => {
//   const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
//   const [isScrolled, setIsScrolled] = useState(false)
  
//   // Handle scroll effect for header
//   useEffect(() => {
//     const handleScroll = () => {
//       if (window.scrollY > 20) {
//         setIsScrolled(true)
//       } else {
//         setIsScrolled(false)
//       }
//     }
    
//     window.addEventListener('scroll', handleScroll)
//     return () => {
//       window.removeEventListener('scroll', handleScroll)
//     }
//   }, [])

//   const closeMobileMenu = () => {
//     setIsMobileMenuOpen(false)
//   }

//   return (
//     <header className={`bg-dark-primary py-4 px-4 sm:px-6 lg:px-8 sticky top-0 z-50 border-b border-dark-border transition-all duration-300 ${isScrolled ? 'shadow-lg shadow-purple-900/20' : ''}`}>
//       <div className="absolute inset-0 bg-animated opacity-30 z-0"></div>
//       <nav className="max-w-7xl mx-auto flex justify-between items-center relative z-10">
//         {/* Logo and Site Title - Navigates to top/home */}
//         <a href="#top" className="flex items-center space-x-3 group" onClick={closeMobileMenu}>
//           <div className="relative overflow-hidden rounded-full p-1 animate-pulse-subtle hover-glow">
//             <img src={logo} alt="ByteBub Logo" className="h-10 w-auto" />
//           </div>
//           <h1 className="text-2xl font-bold text-gradient animate-fade-in-up"></h1>
//         </a>

//         {/* Desktop Navigation */}
//         <div className="hidden md:flex space-x-8">
//           <a href="#top" className="text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group animate-fade-in delay-200 hover-lift">
//             <span>Home</span>
//             <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
//           </a>
//           <a href="#about" className="text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group animate-fade-in delay-300 hover-lift">
//             <span>About Us</span>
//             <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
//           </a>
//           <a href="#capabilities" className="text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group animate-fade-in delay-400 hover-lift">
//             <span>Services</span>
//             <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
//           </a>
//           <a href="#portfolio" className="text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group animate-fade-in delay-500 hover-lift">
//             <span>Portfolio</span>
//             <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
//           </a>
//           <a href="#blog" className="text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group animate-fade-in delay-600 hover-lift">
//             <span>Blog</span>
//             <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
//           </a>
//           <a href="#careers" className="text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group animate-fade-in delay-700 hover-lift">
//             <span>Careers</span>
//             <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
//           </a>
//           <a href="#contact" className="text-dark-text hover:text-dark-accent transition duration-300 relative overflow-hidden group animate-fade-in delay-800 hover-lift">
//             <span>Contact</span>
//             <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-dark-accent transition-all duration-300 group-hover:w-full"></span>
//           </a>
//         </div>

//         {/* Mobile Menu Toggle Button */}
//         <div className="md:hidden">
//           <button
//             onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
//             className="text-dark-text hover:text-dark-accent focus:outline-none w-10 h-10 flex items-center justify-center cursor-pointer relative z-50 hover-glow transition-all duration-300"
//             aria-label="Toggle mobile menu"
//           >
//             {isMobileMenuOpen ? 
//               <X className="h-6 w-6 animate-zoom-in" /> : 
//               <Menu className="h-6 w-6 animate-bounce-subtle" />}
//           </button>
//         </div>
//       </nav>

//       {/* Mobile Menu Overlay */}
//       {isMobileMenuOpen && (
//         <div className="md:hidden fixed inset-0 bg-black bg-opacity-95 backdrop-blur-sm z-40 flex flex-col items-center justify-center space-y-8 animate-fade-in">
//           <div className="absolute inset-0 bg-animated opacity-10"></div>
//           <a href="#top" onClick={closeMobileMenu} className="text-dark-text text-2xl hover:text-dark-accent transition duration-300 animate-slide-in delay-100 relative group">
//             <span>Home</span>
//             <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-dark-accent to-dark-highlight group-hover:w-full transition-all duration-300"></span>
//           </a>
//           <a href="#about" onClick={closeMobileMenu} className="text-dark-text text-2xl hover:text-dark-accent transition duration-300 animate-slide-in delay-200 relative group">
//             <span>About Us</span>
//             <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-dark-accent to-dark-highlight group-hover:w-full transition-all duration-300"></span>
//           </a>
//           <a href="#capabilities" onClick={closeMobileMenu} className="text-dark-text text-2xl hover:text-dark-accent transition duration-300 animate-slide-in delay-300 relative group">
//             <span>Services</span>
//             <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-dark-accent to-dark-highlight group-hover:w-full transition-all duration-300"></span>
//           </a>
//           <a href="#portfolio" onClick={closeMobileMenu} className="text-dark-text text-2xl hover:text-dark-accent transition duration-300 animate-slide-in delay-400 relative group">
//             <span>Portfolio</span>
//             <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-dark-accent to-dark-highlight group-hover:w-full transition-all duration-300"></span>
//           </a>
//           <a href="#blog" onClick={closeMobileMenu} className="text-dark-text text-2xl hover:text-dark-accent transition duration-300 animate-slide-in delay-500 relative group">
//             <span>Blog</span>
//             <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-dark-accent to-dark-highlight group-hover:w-full transition-all duration-300"></span>
//           </a>
//           <a href="#careers" onClick={closeMobileMenu} className="text-dark-text text-2xl hover:text-dark-accent transition duration-300 animate-slide-in delay-600 relative group">
//             <span>Careers</span>
//             <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-dark-accent to-dark-highlight group-hover:w-full transition-all duration-300"></span>
//           </a>
//           <a href="#contact" onClick={closeMobileMenu} className="text-dark-text text-2xl hover:text-dark-accent transition duration-300 animate-slide-in delay-700 relative group">
//             <span>Contact</span>
//             <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-dark-accent to-dark-highlight group-hover:w-full transition-all duration-300"></span>
//           </a>
//         </div>
//       )}
//     </header>
//   )
// }
import { useState, useEffect } from 'react';
import { Menu, ArrowUpRight, X } from 'lucide-react';
import logo from '../assets/logo6.png';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  return (
    <header
      className={`bg-dark-primary py-4 px-4 sm:px-6 lg:px-8 sticky top-0 z-50 border-b border-dark-border transition-all duration-300 backdrop-blur-md bg-opacity-90 ${
        isScrolled ? 'shadow-lg shadow-purple-900/40' : ''
      }`}
    >
      <div className="absolute inset-0 bg-animated opacity-30 z-0"></div>

      <nav className="max-w-7xl mx-auto flex justify-between items-center relative z-10">
        {/* Logo */}
        <a href="#top" className="flex items-center space-x-3" onClick={closeMobileMenu}>
          <div className="overflow-hidden p-1 hover:opacity-90 transition duration-300">
            <img src={logo} alt="ByteBub Logo" className="h-16 w-auto" />
          </div>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8 text-white text-lg font-semibold tracking-wide">
          <a href="#top" className="hover:text-yellow-400 transition">Home</a>
          <a href="#about" className="hover:text-yellow-400 transition">About Us</a>
          <a href="#capabilities" className="hover:text-yellow-400 transition">Services</a>
          <a href="#portfolio" className="hover:text-yellow-400 transition">Portfolio</a>
          <a href="#blog" className="hover:text-yellow-400 transition">Blog</a>
          <a href="#careers" className="hover:text-yellow-400 transition">Careers</a>
        </div>

        {/* Call to Action */}
        <a
          href="#contact"
          className="group relative bg-yellow-400 text-black px-6 py-2 rounded-full font-semibold flex items-center gap-2 transition-all duration-300 hover:scale-105 overflow-hidden"
        >
          <span className="relative z-10 text-lg font-semibold">SAY HI!</span>
          <span className="relative w-5 h-5 overflow-hidden">
            <ArrowUpRight
              size={18}
              className="transform -translate-x-5 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300 ease-in-out"
            />
          </span>
        </a>

        {/* Mobile Menu Toggle */}
        <div className="md:hidden">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-white w-10 h-10 flex items-center justify-center relative z-50"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-black bg-opacity-95 backdrop-blur-sm z-40 flex flex-col items-center justify-center space-y-8">
          <a href="#top" onClick={closeMobileMenu} className="text-white text-xl font-semibold tracking-wide hover:text-yellow-400">Home</a>
          <a href="#about" onClick={closeMobileMenu} className="text-white text-xl font-semibold tracking-wide hover:text-yellow-400">About Us</a>
          <a href="#capabilities" onClick={closeMobileMenu} className="text-white text-xl font-semibold tracking-wide hover:text-yellow-400">Services</a>
          <a href="#portfolio" onClick={closeMobileMenu} className="text-white text-xl font-semibold tracking-wide hover:text-yellow-400">Portfolio</a>
          <a href="#blog" onClick={closeMobileMenu} className="text-white text-xl font-semibold tracking-wide hover:text-yellow-400">Blog</a>
          <a href="#careers" onClick={closeMobileMenu} className="text-white text-xl font-semibold tracking-wide hover:text-yellow-400">Careers</a>
          <a href="#contact" onClick={closeMobileMenu} className="text-white text-xl font-semibold tracking-wide hover:text-yellow-400">SAY HI!</a>
        </div>
      )}
    </header>
  );
};

export default Header;
