import { Mail } from 'lucide-react'

const Portfolio = () => {
  return (
    <section 
      id="portfolio" 
      className="py-16 sm:py-20 lg:py-24 bg-gradient-to-br from-[#1a1a2e] to-[#16213e] rounded-lg shadow-lg border border-dark-border/20 mx-4 sm:mx-6 lg:mx-8 mt-8 relative overflow-hidden"
      data-aos="fade-up"
      data-aos-duration="1200"
      data-aos-easing="ease-in-out"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="relative z-10">
          <h3 className="text-3xl sm:text-4xl font-bold text-white mb-8">Our Portfolio</h3>
          <div className="absolute -top-16 -left-16 w-40 h-40 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-glow-left"></div>
          <div className="absolute -bottom-16 -right-16 w-32 h-32 bg-gradient-to-br from-purple-500/20 to-blue-500/20 rounded-full blur-2xl animate-glow-right"></div>
        </div>
        <p className="text-lg text-dark-muted mb-12">Discover the innovative solutions and impactful projects we've crafted for our diverse clientele. Each project reflects our commitment to quality, creativity, and technical excellence.</p>

        <div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="200"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">AI-Powered Analytics Platform</h4>
            <p className="text-sm text-dark-muted mb-2">Web Development</p>
            <p className="text-dark-muted mb-4">Enterprise-grade dashboard delivering real-time insights and predictive analytics using machine learning.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-purple-600/20 text-purple-400 text-xs font-medium px-2.5 py-0.5 rounded-full">React</span>
              <span className="bg-blue-600/20 text-blue-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Python (Flask)</span>
              <span className="bg-yellow-600/20 text-yellow-400 text-xs font-medium px-2.5 py-0.5 rounded-full">D3.js</span>
              <span className="bg-red-600/20 text-red-400 text-xs font-medium px-2.5 py-0.5 rounded-full">AWS SageMaker</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">View Case Study &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="400"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Global E-commerce Marketplace</h4>
            <p className="text-sm text-dark-muted mb-2">Web Development</p>
            <p className="text-dark-muted mb-4">A multi-vendor e-commerce solution with advanced inventory management and localized payment systems.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-purple-600/20 text-purple-400 text-xs font-medium px-2.5 py-0.5 rounded-full">MERN Stack</span>
              <span className="bg-orange-600/20 text-orange-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Stripe Connect</span>
              <span className="bg-teal-600/20 text-teal-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Elasticsearch</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">View Case Study &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="600"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Health & Wellness Mobile App</h4>
            <p className="text-sm text-dark-muted mb-2">Mobile App Development</p>
            <p className="text-dark-muted mb-4">Cross-platform Flutter app integrating wearable tech for personalized fitness and mindfulness coaching.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-indigo-600/20 text-indigo-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Flutter</span>
              <span className="bg-pink-600/20 text-pink-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Firebase</span>
              <span className="bg-cyan-600/20 text-cyan-400 text-xs font-medium px-2.5 py-0.5 rounded-full">HealthKit/Google Fit API</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">View Case Study &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="800"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Logistics Management System</h4>
            <p className="text-sm text-dark-muted mb-2">Full-Stack Solutions</p>
            <p className="text-dark-muted mb-4">Comprehensive full-stack solution for real-time tracking, route optimization, and fleet management.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-gray-600/20 text-gray-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Java Spring Boot</span>
              <span className="bg-purple-600/20 text-purple-400 text-xs font-medium px-2.5 py-0.5 rounded-full">PostgreSQL</span>
              <span className="bg-blue-600/20 text-blue-400 text-xs font-medium px-2.5 py-0.5 rounded-full">React</span>
              <span className="bg-yellow-600/20 text-yellow-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Kafka</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">View Case Study &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="1000"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Fintech Neobank UI/UX</h4>
            <p className="text-sm text-dark-muted mb-2">UI/UX Design</p>
            <p className="text-dark-muted mb-4">Modern, secure, and intuitive UI/UX design for a challenger bank, focusing on transparency and accessibility.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-purple-600/20 text-purple-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Figma</span>
              <span className="bg-red-600/20 text-red-400 text-xs font-medium px-2.5 py-0.5 rounded-full">User-Centered Design</span>
              <span className="bg-indigo-600/20 text-indigo-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Accessibility Standards</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">View Case Study &rarr;</a>
          </div>

          <div 
            className="bg-dark-card p-6 rounded-xl shadow-lg border border-dark-border hover:shadow-xl transition duration-300 ease-in-out transform hover:-translate-y-2 text-left"
            data-aos="zoom-in"
            data-aos-duration="1200"
            data-aos-delay="1200"
            data-aos-easing="ease-out"
          >
            <h4 className="text-xl font-semibold text-dark-text mb-2">Smart City IoT Platform</h4>
            <p className="text-sm text-dark-muted mb-2">Web Development</p>
            <p className="text-dark-muted mb-4">Web application for monitoring and managing city-wide IoT devices, providing data visualization and control.</p>
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="bg-orange-600/20 text-orange-400 text-xs font-medium px-2.5 py-0.5 rounded-full">React</span>
              <span className="bg-teal-600/20 text-teal-400 text-xs font-medium px-2.5 py-0.5 rounded-full">Node.js</span>
              <span className="bg-pink-600/20 text-pink-400 text-xs font-medium px-2.5 py-0.5 rounded-full">MQTT</span>
              <span className="bg-cyan-600/20 text-cyan-400 text-xs font-medium px-2.5 py-0.5 rounded-full">TimescaleDB</span>
            </div>
            <a href="#" className="text-dark-accent hover:text-dark-highlight font-medium transition duration-300">View Case Study &rarr;</a>
          </div>
        </div>

        <div 
          className="mt-16 bg-dark-accent/30 text-white p-8 rounded-xl shadow-lg border border-dark-accent max-w-2xl mx-auto"
          data-aos="fade-up"
          data-aos-duration="1200"
          data-aos-delay="1400"
          data-aos-easing="ease-out"
        >
          <h4 className="text-2xl font-bold mb-4">Inspired by Our Work?</h4>
          <p className="text-lg mb-6">Let's transform your ideas into reality. Contact us to discuss your project requirements.</p>
          <a
            href="#contact"
            className="inline-flex items-center justify-center px-8 py-4 border border-dark-accent text-base font-medium rounded-full shadow-lg bg-dark-primary text-dark-text hover:bg-dark-accent/20 transition duration-300 ease-in-out transform hover:scale-105 hover-glow"
          >
            Start Your Project
            <Mail className="ml-3 h-5 w-5" />
          </a>
        </div>
      </div>
    </section>
  )
}

export default Portfolio
