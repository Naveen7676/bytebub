// import { useState } from 'react';
// import { Sparkles } from 'lucide-react';

// const ProjectIdeaGenerator = () => {
//   const [projectIdeaInput, setProjectIdeaInput] = useState('');
//   const [generatedProjectIdea, setGeneratedProjectIdea] = useState('');
//   const [isLoadingProjectIdea, setIsLoadingProjectIdea] = useState(false);
//   const [projectIdeaError, setProjectIdeaError] = useState('');

//   const generateProjectIdea = async () => {
//     // Ensure there's input before proceeding
//     if (!projectIdeaInput.trim()) {
//       setProjectIdeaError('Please enter a business idea or problem.');
//       return;
//     }

//     setIsLoadingProjectIdea(true);
//     setGeneratedProjectIdea('');
//     setProjectIdeaError('');

//     // Prepare chat history for the Gemini API call with the prompt directly embedded
//     let chatHistory = [];
//     chatHistory.push({
//       role: "user",
//       parts: [{
//         text: `Given the following business idea or problem, suggest a digital product concept (e.g., web app, mobile app, specific features) and a high-level tech approach (e.g., MERN, Spring Boot, Flutter). Be concise and professional.

// Business Idea/Problem: ${projectIdeaInput}

// Digital Product Concept & Tech Approach:`
//       }]
//     });

//     // Define the payload for the Gemini API call
//     const payload = {
//       contents: chatHistory,
//       generationConfig: {
//         temperature: 0.7, // Controls randomness. Lower values are more deterministic.
//         maxOutputTokens: 500, // Maximum number of tokens to generate in the completion
//       },
//     };

//     // Gemini API endpoint (Canvas will provide the API key at runtime)
//     const apiKey = "AIzaSyBvo6ALE8jLzfY7xoSAD9zx9Ws5_35-LM4"; // Leave this as an empty string; Canvas will provide the API key at runtime.
//     const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

//     try {
//       const response = await fetch(apiUrl, {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(payload),
//       });

//       if (!response.ok) {
//         const err = await response.json();
//         // Log the full error response for debugging
//         console.error('Gemini API error response:', err);
//         throw new Error(err.error?.message || 'Something went wrong with the Gemini API request.');
//       }

//       const result = await response.json();

//       // Extract the generated text from the Gemini response
//       const output = result.candidates?.[0]?.content?.parts?.[0]?.text || '';

//       if (output) {
//         setGeneratedProjectIdea(output.trim());
//       } else {
//         setGeneratedProjectIdea('No suggestion generated. Try modifying your input.');
//       }
//     } catch (error) {
//       console.error('API call error:', error);
//       setProjectIdeaError(error.message || 'Failed to generate idea.');
//     } finally {
//       setIsLoadingProjectIdea(false);
//     }
//   };

//   return (
//     <section id="project-idea" className="py-16 bg-blue-900 text-white rounded-lg shadow-md mx-4 mt-8">
//       <div className="max-w-4xl mx-auto px-6 text-center">
//         <h3 className="text-3xl font-bold mb-8">✨ Spark Your Project Idea ✨</h3>
//         <p className="text-lg mb-8 opacity-90">
//           Describe your business idea or a problem, and get AI-powered product & tech suggestions!
//         </p>
//         <div className="space-y-6">
//           <textarea
//             className="w-full px-4 py-3 rounded-lg bg-white text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-y min-h-[120px]"
//             placeholder="e.g., 'An app for farmers to sell produce directly to consumers.'"
//             value={projectIdeaInput}
//             onChange={(e) => setProjectIdeaInput(e.target.value)}
//             rows="5"
//           ></textarea>

//           <button
//             onClick={generateProjectIdea}
//             disabled={isLoadingProjectIdea || !projectIdeaInput.trim()}
//             className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-medium rounded-full shadow-lg text-blue-900 bg-white hover:bg-gray-100 transition duration-300 ease-in-out transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
//           >
//             {isLoadingProjectIdea ? (
//               <>
//                 <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-blue-900" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
//                   <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
//                   <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
//                 </svg>
//                 Generating...
//               </>
//             ) : (
//               <>
//                 Generate Idea ✨
//                 <Sparkles className="ml-3 h-5 w-5" />
//               </>
//             )}
//           </button>

//           {projectIdeaError && (
//             <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative mt-4" role="alert">
//               <span className="block sm:inline">{projectIdeaError}</span>
//             </div>
//           )}

//           {generatedProjectIdea && (
//             <div className="mt-8 p-6 bg-white text-gray-800 rounded-xl shadow-lg text-left whitespace-pre-wrap">
//               {/* Removed the 'Our Suggestion:' heading */}
//               <p>{generatedProjectIdea}</p>
//             </div>
//           )}
//         </div>
//       </div>
//     </section>
//   );
// };

// export default ProjectIdeaGenerator;