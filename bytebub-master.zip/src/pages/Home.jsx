import Hero from '../components/Hero';
import About from '../components/About';
import Services from './Services';
import Portfolio from './Portfolio';
import Blog from '../components/Blog';
import TechStack from '../components/TechStack';

const Home = () => {
  return (
    <main className="min-h-screen bg-dark-primary text-white">
      <Hero />
      <About />
      <Services />
      <Portfolio />
      <Blog />
      <TechStack />
    </main>
  );
};

export default Home;
