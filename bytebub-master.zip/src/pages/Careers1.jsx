import React from 'react';

const Careers = () => {
  return (
    <section className="min-h-screen bg-dark-primary text-white p-8">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Join Our Team</h1>
        <p className="text-lg mb-4">
          We’re always looking for talented individuals to join our growing team. If you're passionate, driven, and ready to make an impact — let’s talk.
        </p>

        {/* Example Job Listings */}
        <div className="space-y-4">
          <div className="p-6 bg-dark-secondary rounded-md shadow-md">
            <h2 className="text-2xl font-semibold">Frontend Developer</h2>
            <p className="mt-2 text-gray-300">Location: Remote | Experience: 2+ years</p>
          </div>
          <div className="p-6 bg-dark-secondary rounded-md shadow-md">
            <h2 className="text-2xl font-semibold">UI/UX Designer</h2>
            <p className="mt-2 text-gray-300">Location: Remote | Experience: 3+ years</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Careers;
